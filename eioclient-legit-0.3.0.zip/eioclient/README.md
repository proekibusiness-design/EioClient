# Eio Client 0.3.0 — Legit Build

A Fabric 1.21.4 quality-of-life client. This build intentionally contains no anticheat bypass, packet spoofing, detection-threshold tuning, or other evasion logic.

## Setup
1. Use Java 21.
2. Open this folder as a Gradle/Fabric project.
3. Run `gradlew runClient` (or generate/use a Gradle wrapper if your IDE does not provide Gradle).
4. Build with `gradlew build`; the mod jar is produced under `build/libs/`.

## GUI
- Right Shift opens/closes the GUI while in a world.
- Left-click a module to toggle it.
- Right-click a module to expand settings/keybind.
- Click Keybind then press a key. Backspace/Delete clears; Esc cancels.
- Slider settings can be dragged. Panel headers can be dragged.
- Config is stored in `<minecraft>/config/eioclient.json`.

## Modules
- Movement: Sprint, AutoWalk, Follow, Fly
- Render: HUD, Fullbright

`Fly` and automated movement should only be used where the game/server rules permit them (for example single-player, creative/testing, or a server that explicitly allows them). They are not designed to bypass server enforcement.

## Commands
- `/toggle <module>`
- `/bind <module> <key|none>`
- `/follow add|remove|only <entity>`
- `/follow clear`
- `/follow list`
- `/config save`
- `/config load`

## Reliability changes in 0.3.0
- Removed the AnticheatExempt/bypass-related module from the client.
- Keybind-triggered module state is saved immediately.
- Config writes prefer atomic replacement to reduce corruption risk.
- Invalid config files are preserved as `eioclient.json.broken` for recovery.
- Fullbright no longer intentionally removes a pre-existing night-vision effect when disabled.
