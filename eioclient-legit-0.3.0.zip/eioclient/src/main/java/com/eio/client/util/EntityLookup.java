package com.eio.client.util;

import net.minecraft.entity.EntityType;
import net.minecraft.registry.Registries;
import net.minecraft.util.Identifier;

import java.util.Collection;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.TreeMap;

/**
 * Maps friendly names ("skeleton", "minecraft:skeleton", "somemod:thing") to
 * EntityTypes, built from the game registry so every entity in the game
 * (including modded ones) is available.
 */
public final class EntityLookup {
    private static Map<String, EntityType<?>> byName;       // accepts short and full ids
    private static Map<String, EntityType<?>> displayNames; // sorted names for suggestions

    private EntityLookup() {}

    private static void build() {
        if (byName != null) return;
        byName = new HashMap<>();
        displayNames = new TreeMap<>();
        for (EntityType<?> type : Registries.ENTITY_TYPE) {
            Identifier id = Registries.ENTITY_TYPE.getId(type);
            String display = nameOf(type);
            byName.put(id.toString(), type);
            byName.put(display, type);
            displayNames.put(display, type);
        }
    }

    /** Short name for vanilla ("skeleton"), full id for modded ("mod:thing"). */
    public static String nameOf(EntityType<?> type) {
        Identifier id = Registries.ENTITY_TYPE.getId(type);
        return id.getNamespace().equals("minecraft") ? id.getPath() : id.toString();
    }

    public static EntityType<?> find(String input) {
        build();
        String key = input.trim().toLowerCase(Locale.ROOT);
        EntityType<?> t = byName.get(key);
        if (t == null && !key.contains(":")) t = byName.get("minecraft:" + key);
        return t;
    }

    public static Collection<String> names() {
        build();
        return displayNames.keySet();
    }
}
