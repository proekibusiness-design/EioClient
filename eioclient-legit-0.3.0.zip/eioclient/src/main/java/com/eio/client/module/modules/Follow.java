package com.eio.client.module.modules;

import com.eio.client.module.Category;
import com.eio.client.module.Module;
import com.eio.client.setting.BoolSetting;
import com.eio.client.setting.NumberSetting;
import com.eio.client.util.EntityLookup;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.text.Text;
import net.minecraft.util.math.MathHelper;

import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.Set;

/**
 * Walks toward the nearest entity whose type is in the target set.
 * Any entity type in the game can be a target (managed with /follow ...).
 */
public class Follow extends Module {
    private final NumberSetting range = addSetting(new NumberSetting("Range", 32, 4, 128, 1));
    private final NumberSetting stopDistance = addSetting(new NumberSetting("Stop distance", 2.0, 0.5, 10, 0.5));
    private final NumberSetting turnSpeed = addSetting(new NumberSetting("Turn speed", 40, 5, 180, 5));
    private final BoolSetting autoJump = addSetting(new BoolSetting("Auto jump", true));

    private final Set<EntityType<?>> targets = new LinkedHashSet<>();

    public Follow() {
        super("Follow", "Walks toward the nearest entity of the chosen types.", Category.MOVEMENT);
    }

    // ----- target management (used by /follow) -----

    public void addTarget(EntityType<?> type) { targets.add(type); }
    public void removeTarget(EntityType<?> type) { targets.remove(type); }
    public void clearTargets() { targets.clear(); }
    public void setOnly(EntityType<?> type) { targets.clear(); targets.add(type); }
    public Set<EntityType<?>> getTargets() { return Collections.unmodifiableSet(targets); }

    // ----- module hooks -----

    @Override
    protected void onEnable() {
        if (targets.isEmpty() && mc.player != null) {
            mc.player.sendMessage(Text.literal("Follow: no targets set. Use /follow add <entity>"), false);
        }
    }

    @Override
    protected void onDisable() {
        releaseKeys();
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.world == null || targets.isEmpty()) {
            releaseKeys();
            return;
        }

        Entity target = findNearest();
        if (target == null) {
            releaseKeys();
            return;
        }

        // Turn toward the target (smoothly, capped by Turn speed).
        double dx = target.getX() - mc.player.getX();
        double dz = target.getZ() - mc.player.getZ();
        float wanted = (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
        float current = mc.player.getYaw();
        float delta = MathHelper.wrapDegrees(wanted - current);
        float step = MathHelper.clamp(delta, -turnSpeed.getFloat(), turnSpeed.getFloat());
        mc.player.setYaw(current + step);

        // Walk forward until close enough.
        boolean walk = mc.player.distanceTo(target) > stopDistance.get();
        mc.options.forwardKey.setPressed(walk);
        mc.options.jumpKey.setPressed(
            autoJump.get() && walk && mc.player.horizontalCollision && mc.player.isOnGround());
    }

    @Override
    public void saveExtra(JsonObject out) {
        JsonArray arr = new JsonArray();
        for (EntityType<?> t : targets) arr.add(EntityLookup.nameOf(t));
        out.add("targets", arr);
    }

    @Override
    public void loadExtra(JsonObject in) {
        targets.clear();
        if (!in.has("targets")) return;
        for (JsonElement e : in.getAsJsonArray("targets")) {
            EntityType<?> t = EntityLookup.find(e.getAsString());
            if (t != null) targets.add(t);
        }
    }

    private Entity findNearest() {
        double maxSq = range.get() * range.get();
        Entity best = null;
        double bestSq = maxSq;
        for (Entity e : mc.world.getEntities()) {
            if (e == mc.player || e.isRemoved()) continue;
            if (!targets.contains(e.getType())) continue;
            double sq = mc.player.squaredDistanceTo(e);
            if (sq <= bestSq) {
                bestSq = sq;
                best = e;
            }
        }
        return best;
    }

    private void releaseKeys() {
        if (mc.options == null) return;
        mc.options.forwardKey.setPressed(false);
        mc.options.jumpKey.setPressed(false);
    }
}
