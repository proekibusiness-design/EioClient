package com.eio.client.gui;

import com.eio.client.EioClient;
import com.eio.client.TitleBranding;
import com.eio.client.config.Config;
import com.eio.client.module.modules.Follow;
import com.eio.client.util.EntityLookup;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.entity.EntityType;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;

/** Paged grid of every entity type in the game; click one to toggle it as a Follow target. */
public class EntityPickerScreen extends Screen {
    private static final int CELL_W = 112, ROW_H = 14, GRID_TOP = 68;

    private final Follow follow;
    private final List<String> names = new ArrayList<>(EntityLookup.names());
    private int page;
    private String query = "";
    private final boolean[] prevKeys = new boolean[GLFW.GLFW_KEY_LAST + 1];
    private boolean prevLeft = Input.mouseDown(GLFW.GLFW_MOUSE_BUTTON_LEFT);

    public EntityPickerScreen(Follow follow) {
        super(Text.literal("Follow targets"));
        this.follow = follow;
        for (int k = GLFW.GLFW_KEY_SPACE; k <= GLFW.GLFW_KEY_LAST; k++) prevKeys[k] = Input.keyDown(k);
    }

    /** Polls the keyboard for search text: letters, digits, Space (as _), Backspace. */
    private void pollTyping() {
        for (int k = GLFW.GLFW_KEY_SPACE; k <= GLFW.GLFW_KEY_LAST; k++) {
            boolean down = Input.keyDown(k);
            boolean pressed = down && !prevKeys[k];
            prevKeys[k] = down;
            if (!pressed) continue;
            String before = query;
            if (k >= GLFW.GLFW_KEY_A && k <= GLFW.GLFW_KEY_Z) query += (char) ('a' + (k - GLFW.GLFW_KEY_A));
            else if (k >= GLFW.GLFW_KEY_0 && k <= GLFW.GLFW_KEY_9) query += (char) ('0' + (k - GLFW.GLFW_KEY_0));
            else if (k == GLFW.GLFW_KEY_SPACE) query += "_";
            else if (k == GLFW.GLFW_KEY_BACKSPACE && !query.isEmpty()) query = query.substring(0, query.length() - 1);
            if (!query.equals(before)) page = 0;
        }
    }

    private List<String> filtered() {
        if (query.isEmpty()) return names;
        List<String> out = new ArrayList<>();
        for (String n : names) if (n.contains(query)) out.add(n);
        return out;
    }

    @Override
    public boolean shouldPause() { return false; }

    @Override
    public void removed() {
        Config.save(EioClient.modules);
    }

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        boolean left = Input.mouseDown(GLFW.GLFW_MOUSE_BUTTON_LEFT);
        boolean click = left && !prevLeft;
        prevLeft = left;
        pollTyping();
        List<String> view = filtered();

        TextRenderer tr = this.textRenderer;
        ctx.fill(0, 0, width, height, 0xAA000000);

        String title = "Follow targets";
        TitleBranding.drawRainbow(ctx, tr, title, (width - tr.getWidth(title)) / 2, 8);

        int cols = Math.max(1, Math.min(5, (width - 16) / CELL_W));
        int rows = Math.max(1, (height - GRID_TOP - 20) / ROW_H);
        int perPage = cols * rows;
        int pages = Math.max(1, (view.size() + perPage - 1) / perPage);
        page = Math.max(0, Math.min(page, pages - 1));

        // Button row
        int bx = (width - 4 * 64 - 3 * 6) / 2;
        if (button(ctx, tr, "< Prev", bx, 22, 64, mx, my, click)) page = Math.max(0, page - 1);
        if (button(ctx, tr, "Next >", bx + 70, 22, 64, mx, my, click)) page = Math.min(pages - 1, page + 1);
        if (button(ctx, tr, "Clear", bx + 140, 22, 64, mx, my, click)) follow.clearTargets();
        if (button(ctx, tr, "Back", bx + 210, 22, 64, mx, my, click)) {
            MinecraftClient.getInstance().setScreen(new ClickGuiScreen());
            return;
        }

        int boxW = 180;
        int boxX = (width - boxW) / 2;
        ctx.fill(boxX, 38, boxX + boxW, 52, 0xFF111111);
        boolean blink = (System.currentTimeMillis() / 500) % 2 == 0;
        String shown = query.isEmpty() ? "Type to search..." : query + (blink ? "_" : "");
        ctx.drawTextWithShadow(tr, shown, boxX + 4, 41, query.isEmpty() ? 0xFF777777 : 0xFFFFFFFF);

        String info = "Selected: " + follow.getTargets().size() + "   Showing " + view.size()
            + "   Page " + (page + 1) + "/" + pages;
        ctx.drawTextWithShadow(tr, info, (width - tr.getWidth(info)) / 2, 56, 0xFFAAAAAA);

        // Grid
        int gridX = (width - cols * CELL_W) / 2;
        int start = page * perPage;
        for (int i = 0; i < perPage && start + i < view.size(); i++) {
            String name = view.get(start + i);
            EntityType<?> type = EntityLookup.find(name);
            if (type == null) continue;

            int cx = gridX + (i % cols) * CELL_W;
            int cy = GRID_TOP + (i / cols) * ROW_H;
            boolean selected = follow.getTargets().contains(type);
            boolean hover = GuiHit.in(mx, my, cx, cy, CELL_W - 2, ROW_H - 1);

            int bg = selected ? (hover ? 0xFF4A90E2 : 0xFF3A7BD5)
                              : (hover ? 0xDD333333 : 0xDD1E1E1E);
            ctx.fill(cx, cy, cx + CELL_W - 2, cy + ROW_H - 1, bg);
            ctx.drawTextWithShadow(tr, tr.trimToWidth(name, CELL_W - 10), cx + 4, cy + 3, 0xFFFFFFFF);

            if (hover && click) {
                if (selected) follow.removeTarget(type); else follow.addTarget(type);
            }
        }
    }

    private boolean button(DrawContext ctx, TextRenderer tr, String label,
                           int x, int y, int w, int mx, int my, boolean click) {
        boolean hover = GuiHit.in(mx, my, x, y, w, 14);
        ctx.fill(x, y, x + w, y + 14, hover ? 0xFF3A3A3A : 0xFF222222);
        ctx.drawTextWithShadow(tr, label, x + (w - tr.getWidth(label)) / 2, y + 3, 0xFFFFFFFF);
        return hover && click;
    }
}
