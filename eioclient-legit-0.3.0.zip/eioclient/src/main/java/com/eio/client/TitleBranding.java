package com.eio.client;

import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.TitleScreen;

/** Animated rainbow text: the title-screen banner, also reused by the GUI. */
public final class TitleBranding {
    private static final String TEXT = "Eio Client - made by Eio";

    private TitleBranding() {}

    public static void init() {
        ScreenEvents.AFTER_INIT.register((client, screen, scaledWidth, scaledHeight) -> {
            if (screen instanceof TitleScreen) {
                ScreenEvents.afterRender(screen).register((s, ctx, mouseX, mouseY, tickDelta) -> {
                    TextRenderer tr = MinecraftClient.getInstance().textRenderer;
                    drawRainbow(ctx, tr, TEXT, (s.width - tr.getWidth(TEXT)) / 2, 8);
                });
            }
        });
    }

    /** Draws text one character at a time with a scrolling rainbow. */
    public static void drawRainbow(DrawContext ctx, TextRenderer tr, String text, int x, int y) {
        long t = System.currentTimeMillis();
        for (int i = 0; i < text.length(); i++) {
            String ch = String.valueOf(text.charAt(i));
            float hue = (((t % 3000L) / 3000f) + i * 0.045f) % 1f;
            ctx.drawTextWithShadow(tr, ch, x, y, 0xFF000000 | hsvToRgb(hue));
            x += tr.getWidth(ch);
        }
    }

    /** Hue 0..1 at full saturation and brightness -> 0xRRGGBB. */
    public static int hsvToRgb(float h) {
        float h6 = h * 6f;
        int sector = (int) Math.floor(h6) % 6;
        float f = h6 - (float) Math.floor(h6);
        float q = 1f - f;
        float r, g, b;
        switch (sector) {
            case 0 -> { r = 1; g = f; b = 0; }
            case 1 -> { r = q; g = 1; b = 0; }
            case 2 -> { r = 0; g = 1; b = f; }
            case 3 -> { r = 0; g = q; b = 1; }
            case 4 -> { r = f; g = 0; b = 1; }
            default -> { r = 1; g = 0; b = q; }
        }
        return ((int) (r * 255) << 16) | ((int) (g * 255) << 8) | (int) (b * 255);
    }
}
