package com.eio.client;

import com.eio.client.config.Config;
import com.eio.client.module.Module;
import com.eio.client.util.KeyNames;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource;
import net.minecraft.command.CommandSource;
import net.minecraft.text.Text;

/**
 * /bind <module> <key|none>   e.g. /bind Fly R   /bind Fly none
 * /config save | /config load
 */
public final class ConfigCommands {
    private ConfigCommands() {}

    public static void register(CommandDispatcher<FabricClientCommandSource> dispatcher) {
        dispatcher.register(ClientCommandManager.literal("bind")
            .then(ClientCommandManager.argument("module", StringArgumentType.word())
                .suggests((ctx, b) -> CommandSource.suggestMatching(
                    EioClient.modules.getAll().stream().map(Module::getName), b))
                .then(ClientCommandManager.argument("key", StringArgumentType.word())
                    .executes(ctx -> {
                        String modName = StringArgumentType.getString(ctx, "module");
                        String keyName = StringArgumentType.getString(ctx, "key");
                        Module m = EioClient.modules.get(modName);
                        if (m == null) {
                            ctx.getSource().sendFeedback(Text.literal("Unknown module: " + modName));
                            return 0;
                        }
                        int key = KeyNames.parse(keyName);
                        if (key < 0 && !keyName.equalsIgnoreCase("none")) {
                            ctx.getSource().sendFeedback(Text.literal("Unknown key: " + keyName));
                            return 0;
                        }
                        m.setKey(key);
                        Config.save(EioClient.modules);
                        ctx.getSource().sendFeedback(Text.literal(
                            m.getName() + " bound to " + KeyNames.of(key)));
                        return 1;
                    }))));

        dispatcher.register(ClientCommandManager.literal("config")
            .then(ClientCommandManager.literal("save").executes(ctx -> {
                Config.save(EioClient.modules);
                ctx.getSource().sendFeedback(Text.literal("Config saved"));
                return 1;
            }))
            .then(ClientCommandManager.literal("load").executes(ctx -> {
                Config.load(EioClient.modules);
                ctx.getSource().sendFeedback(Text.literal("Config loaded"));
                return 1;
            })));
    }
}
