package com.eio.client;

import com.eio.client.config.Config;
import com.eio.client.module.modules.Follow;
import com.eio.client.util.EntityLookup;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource;
import net.minecraft.command.CommandSource;
import net.minecraft.entity.EntityType;
import net.minecraft.text.Text;

import java.util.function.BiFunction;
import java.util.stream.Collectors;

/**
 * /follow add <entity>     start following this type (can add several)
 * /follow remove <entity>  stop following this type
 * /follow only <entity>    follow just this type
 * /follow clear            remove all types
 * /follow list             show current types
 * Turn the module itself on/off with /toggle Follow.
 */
public final class FollowCommand {
    private FollowCommand() {}

    public static void register(CommandDispatcher<FabricClientCommandSource> dispatcher) {
        dispatcher.register(ClientCommandManager.literal("follow")
            .then(entityCommand("add", (f, t) -> {
                f.addTarget(t);
                return "Following " + EntityLookup.nameOf(t);
            }))
            .then(entityCommand("remove", (f, t) -> {
                f.removeTarget(t);
                return "No longer following " + EntityLookup.nameOf(t);
            }))
            .then(entityCommand("only", (f, t) -> {
                f.setOnly(t);
                return "Following only " + EntityLookup.nameOf(t);
            }))
            .then(ClientCommandManager.literal("clear").executes(ctx -> {
                follow().clearTargets();
                Config.save(EioClient.modules);
                ctx.getSource().sendFeedback(Text.literal("Follow targets cleared"));
                return 1;
            }))
            .then(ClientCommandManager.literal("list").executes(ctx -> {
                String names = follow().getTargets().stream()
                    .map(EntityLookup::nameOf)
                    .collect(Collectors.joining(", "));
                ctx.getSource().sendFeedback(Text.literal(
                    "Follow targets: " + (names.isEmpty() ? "none" : names)
                    + " (" + (follow().isEnabled() ? "on" : "off") + ")"));
                return 1;
            })));
    }

    private static Follow follow() {
        return EioClient.modules.get(Follow.class);
    }

    private static LiteralArgumentBuilder<FabricClientCommandSource> entityCommand(
            String literal, BiFunction<Follow, EntityType<?>, String> action) {
        return ClientCommandManager.literal(literal).then(
            ClientCommandManager.argument("entity", StringArgumentType.greedyString())
                .suggests((ctx, builder) -> CommandSource.suggestMatching(EntityLookup.names(), builder))
                .executes(ctx -> {
                    String name = StringArgumentType.getString(ctx, "entity");
                    EntityType<?> type = EntityLookup.find(name);
                    if (type == null) {
                        ctx.getSource().sendFeedback(Text.literal("Unknown entity: " + name));
                        return 0;
                    }
                    String msg = action.apply(follow(), type);
                    if (!follow().isEnabled()) msg += " (Follow is off: /toggle Follow)";
                    Config.save(EioClient.modules);
                    ctx.getSource().sendFeedback(Text.literal(msg));
                    return 1;
                }));
    }
}
