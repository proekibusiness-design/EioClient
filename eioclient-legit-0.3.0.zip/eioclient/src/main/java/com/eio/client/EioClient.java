package com.eio.client;

import com.eio.client.config.Config;
import com.eio.client.event.EventBus;
import com.eio.client.event.TickEvent;
import com.eio.client.gui.GuiKeybind;
import com.eio.client.module.Module;
import com.eio.client.module.ModuleManager;
import com.eio.client.module.modules.Hud;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.command.CommandSource;
import net.minecraft.text.Text;

/**
 * Entry point. Version-sensitive wiring lives here and in TitleBranding, the
 * command classes and the gui package, so the rest of the framework stays portable.
 */
public class EioClient implements ClientModInitializer {
    public static final String NAME = "Eio Client";
    public static final EventBus EVENTS = new EventBus();
    public static ModuleManager modules;

    @Override
    public void onInitializeClient() {
        modules = new ModuleManager(EVENTS);
        Config.load(modules);

        TitleBranding.init();

        // Per-tick: GUI key, module keybinds, then module logic.
        ClientTickEvents.END_CLIENT_TICK.register(GuiKeybind::tick);
        ClientTickEvents.END_CLIENT_TICK.register(client -> modules.handleKeys(client));
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.player != null && client.world != null) {
                EVENTS.post(new TickEvent());
            }
        });

        // In-game overlay.
        HudRenderCallback.EVENT.register((ctx, tickCounter) -> {
            Hud hud = modules.get(Hud.class);
            if (hud != null && hud.isEnabled()) hud.render(ctx);
        });

        // Save on exit.
        ClientLifecycleEvents.CLIENT_STOPPING.register(client -> Config.save(modules));

        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) -> {
            // /toggle <module>  (client-side only, never sent to the server)
            dispatcher.register(ClientCommandManager.literal("toggle")
                .then(ClientCommandManager.argument("module", StringArgumentType.word())
                    .suggests((ctx, builder) -> CommandSource.suggestMatching(
                        modules.getAll().stream().map(Module::getName), builder))
                    .executes(ctx -> {
                        String name = StringArgumentType.getString(ctx, "module");
                        Module m = modules.get(name);
                        if (m == null) {
                            ctx.getSource().sendFeedback(Text.literal("Unknown module: " + name));
                            return 0;
                        }
                        m.toggle();
                        Config.save(modules);
                        ctx.getSource().sendFeedback(Text.literal(
                            m.getName() + " " + (m.isEnabled() ? "enabled" : "disabled")));
                        return 1;
                    })));

            FollowCommand.register(dispatcher);
            ConfigCommands.register(dispatcher);
        });
    }
}
