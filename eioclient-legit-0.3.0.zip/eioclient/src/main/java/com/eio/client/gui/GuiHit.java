package com.eio.client.gui;

final class GuiHit {
    private GuiHit() {}

    static boolean in(int mx, int my, int x, int y, int w, int h) {
        return mx >= x && mx < x + w && my >= y && my < y + h;
    }
}
