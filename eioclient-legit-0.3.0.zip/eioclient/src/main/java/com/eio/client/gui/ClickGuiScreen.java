package com.eio.client.gui;

import com.eio.client.EioClient;
import com.eio.client.TitleBranding;
import com.eio.client.config.Config;
import com.eio.client.module.Category;
import com.eio.client.module.Module;
import com.eio.client.module.modules.Follow;
import com.eio.client.setting.BoolSetting;
import com.eio.client.setting.ModeSetting;
import com.eio.client.setting.NumberSetting;
import com.eio.client.setting.Setting;
import com.eio.client.setting.StringSetting;
import com.eio.client.util.KeyNames;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import net.minecraft.util.math.MathHelper;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Main GUI. Left-click a module to toggle it, right-click to expand its settings
 * (including its keybind). Drag sliders. Follow has a Targets row for the entity picker.
 * Settings are saved to disk when the GUI closes.
 */
public class ClickGuiScreen extends Screen {
    private static final int PANEL_W = 130, HEADER_H = 16, ROW_H = 14, GAP = 8, TOP = 24;
    private static final Set<Module> EXPANDED = new HashSet<>();
    private static final Map<Category, int[]> POS = new HashMap<>(); // panel positions, kept while the game runs

    private static Module listening;                       // module currently being rebound
    private static final boolean[] LISTEN_PREV = new boolean[GLFW.GLFW_KEY_LAST + 1];

    private boolean prevLeft = Input.mouseDown(GLFW.GLFW_MOUSE_BUTTON_LEFT);
    private boolean prevRight = Input.mouseDown(GLFW.GLFW_MOUSE_BUTTON_RIGHT);
    private NumberSetting dragging;
    private Category draggingPanel;
    private int dragOffX, dragOffY;
    private int dragX, dragW;
    private String hoverText = "";
    private String notice = "";
    private long noticeUntil;

    public ClickGuiScreen() {
        super(Text.literal("Eio Client"));
    }

    public static boolean isListening() { return listening != null; }

    @Override
    public boolean shouldPause() { return false; }

    @Override
    public void removed() {
        listening = null;
        Config.save(EioClient.modules);
    }

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        boolean left = Input.mouseDown(GLFW.GLFW_MOUSE_BUTTON_LEFT);
        boolean right = Input.mouseDown(GLFW.GLFW_MOUSE_BUTTON_RIGHT);
        boolean lClick = left && !prevLeft;
        boolean rClick = right && !prevRight;
        prevLeft = left;
        prevRight = right;
        if (!left) dragging = null;
        hoverText = "";

        if (listening != null) pollBind();

        TextRenderer tr = this.textRenderer;
        ctx.fill(0, 0, width, height, 0x88000000);

        String title = "Eio Client";
        TitleBranding.drawRainbow(ctx, tr, title, (width - tr.getWidth(title)) / 2, 8);

        List<Category> cats = new ArrayList<>();
        for (Category c : Category.values()) {
            if (!EioClient.modules.getByCategory(c).isEmpty()) cats.add(c);
        }
        int total = cats.size() * PANEL_W + Math.max(0, cats.size() - 1) * GAP;
        int x = (width - total) / 2;
        for (Category c : cats) {
            drawPanel(ctx, tr, c, x, mx, my, lClick, rClick, left);
            x += PANEL_W + GAP;
        }

        String hint;
        if (System.currentTimeMillis() < noticeUntil) hint = notice;
        else if (listening != null) hint = "Press a key to bind " + listening.getName()
            + "  (Backspace: unbind, Esc: cancel)";
        else if (!hoverText.isEmpty()) hint = hoverText;
        else hint = "Left-click: toggle  |  Right-click: settings & keybind  |  Drag headers to move  |  Right Shift: close";
        ctx.drawTextWithShadow(tr, hint, 6, height - 12, 0xFFAAAAAA);
    }

    private void startListening(Module m) {
        listening = m;
        for (int k = GLFW.GLFW_KEY_SPACE; k <= GLFW.GLFW_KEY_LAST; k++) {
            LISTEN_PREV[k] = Input.keyDown(k); // ignore keys that are already held
        }
    }

    private void pollBind() {
        for (int k = GLFW.GLFW_KEY_SPACE; k <= GLFW.GLFW_KEY_LAST; k++) {
            boolean down = Input.keyDown(k);
            boolean pressed = down && !LISTEN_PREV[k];
            LISTEN_PREV[k] = down;
            if (!pressed) continue;

            if (k == GLFW.GLFW_KEY_ESCAPE) { listening = null; return; }
            if (k == GLFW.GLFW_KEY_BACKSPACE || k == GLFW.GLFW_KEY_DELETE) {
                listening.setKey(-1);
                listening = null;
                Config.save(EioClient.modules);
                return;
            }
            if (k == GuiKeybind.OPEN_KEY) {
                notice = KeyNames.of(k) + " is reserved for opening the GUI.";
                noticeUntil = System.currentTimeMillis() + 2500;
                continue;
            }
            listening.setKey(k);
            listening = null;
            Config.save(EioClient.modules);
            return;
        }
    }

    private void drawPanel(DrawContext ctx, TextRenderer tr, Category c, int defaultX,
                           int mx, int my, boolean lClick, boolean rClick, boolean left) {
        int[] pos = POS.computeIfAbsent(c, k -> new int[]{defaultX, TOP});
        int x = pos[0];
        int y = pos[1];

        // Drag panels by their header.
        if (in(mx, my, x, y, PANEL_W, HEADER_H) && lClick && draggingPanel == null && dragging == null) {
            draggingPanel = c;
            dragOffX = mx - x;
            dragOffY = my - y;
        }
        if (draggingPanel == c) {
            if (left) {
                pos[0] = MathHelper.clamp(mx - dragOffX, 0, Math.max(0, width - PANEL_W));
                pos[1] = MathHelper.clamp(my - dragOffY, 0, Math.max(0, height - HEADER_H));
                x = pos[0];
                y = pos[1];
            } else {
                draggingPanel = null;
            }
        }

        ctx.fill(x, y, x + PANEL_W, y + HEADER_H, 0xFF202020);
        String name = c.name().charAt(0) + c.name().substring(1).toLowerCase();
        TitleBranding.drawRainbow(ctx, tr, name, x + 6, y + 4);
        y += HEADER_H;

        for (Module m : EioClient.modules.getByCategory(c)) {
            boolean hover = in(mx, my, x, y, PANEL_W, ROW_H);
            int bg = m.isEnabled() ? (hover ? 0xFF4A90E2 : 0xFF3A7BD5)
                                   : (hover ? 0xDD333333 : 0xDD1E1E1E);
            ctx.fill(x, y, x + PANEL_W, y + ROW_H, bg);
            ctx.drawTextWithShadow(tr, m.getName(), x + 6, y + 3, 0xFFFFFFFF);

            int rightEdge = x + PANEL_W - 10;
            ctx.drawTextWithShadow(tr, EXPANDED.contains(m) ? "v" : ">", rightEdge, y + 3, 0xFFCCCCCC);
            if (m.getKey() >= 0) {
                String k = "[" + KeyNames.of(m.getKey()) + "]";
                ctx.drawTextWithShadow(tr, k, rightEdge - tr.getWidth(k) - 4, y + 3, 0xFFBBBBBB);
            }

            if (hover) {
                hoverText = m.getDescription();
                if (lClick) m.toggle();
                if (rClick && !EXPANDED.remove(m)) EXPANDED.add(m);
            }
            y += ROW_H;

            if (EXPANDED.contains(m)) {
                y = drawSettings(ctx, tr, m, x, y, mx, my, lClick, left);
            }
        }
    }

    private int drawSettings(DrawContext ctx, TextRenderer tr, Module m, int px, int y,
                             int mx, int my, boolean lClick, boolean left) {
        int x = px + 4;
        int w = PANEL_W - 4;

        // Keybind row
        {
            boolean hover = in(mx, my, x, y, w, ROW_H);
            boolean waiting = listening == m;
            ctx.fill(x, y, x + w, y + ROW_H, waiting ? 0xDD5A4A10 : (hover ? 0xDD2A2A2A : 0xDD151515));
            ctx.drawTextWithShadow(tr, "Keybind", x + 4, y + 3, 0xFFDDDDDD);
            String v = waiting ? "..." : KeyNames.of(m.getKey());
            ctx.drawTextWithShadow(tr, v, x + w - tr.getWidth(v) - 4, y + 3, 0xFFFFD866);
            if (hover) {
                hoverText = "Click, then press a key to bind " + m.getName() + ".";
                if (lClick) startListening(m);
            }
            y += ROW_H;
        }

        for (Setting<?> s : m.getSettings()) {
            boolean hover = in(mx, my, x, y, w, ROW_H);
            ctx.fill(x, y, x + w, y + ROW_H, hover ? 0xDD2A2A2A : 0xDD151515);

            if (s instanceof BoolSetting b) {
                ctx.drawTextWithShadow(tr, b.getName(), x + 4, y + 3, 0xFFDDDDDD);
                String v = b.get() ? "ON" : "OFF";
                ctx.drawTextWithShadow(tr, v, x + w - tr.getWidth(v) - 4, y + 3,
                    b.get() ? 0xFF55FF55 : 0xFFFF5555);
                if (hover && lClick) b.toggle();

            } else if (s instanceof NumberSetting n) {
                double ratio = (n.get() - n.getMin()) / (n.getMax() - n.getMin());
                ctx.fill(x, y, x + (int) (w * ratio), y + ROW_H, 0xFF2F5F9F);
                String v = n.getStep() < 0.1 ? String.format("%.2f", n.get()) : String.format("%.1f", n.get());
                ctx.drawTextWithShadow(tr, n.getName(), x + 4, y + 3, 0xFFDDDDDD);
                ctx.drawTextWithShadow(tr, v, x + w - tr.getWidth(v) - 4, y + 3, 0xFFFFFFFF);
                if (hover && lClick) { dragging = n; dragX = x; dragW = w; }
                if (dragging == n && left) {
                    double r = MathHelper.clamp((mx - dragX) / (double) dragW, 0.0, 1.0);
                    double val = n.getMin() + r * (n.getMax() - n.getMin());
                    n.set(Math.round(val / n.getStep()) * n.getStep());
                }

            } else if (s instanceof StringSetting ss) {
                ctx.drawTextWithShadow(tr, ss.getName(), x + 4, y + 3, 0xFFDDDDDD);
                String v = ss.get().isEmpty() ? "(empty)" : tr.trimToWidth(ss.get(), 50);
                ctx.drawTextWithShadow(tr, v, x + w - tr.getWidth(v) - 4, y + 3, 0xFF999999);
                if (hover) hoverText = "Edit in config/eioclient.json, then run /config load.";

            } else if (s instanceof ModeSetting ms) {
                ctx.drawTextWithShadow(tr, ms.getName(), x + 4, y + 3, 0xFFDDDDDD);
                String v = ms.get();
                ctx.drawTextWithShadow(tr, v, x + w - tr.getWidth(v) - 4, y + 3, 0xFFFFFFFF);
                if (hover && lClick) ms.cycle();
            }
            y += ROW_H;
        }

        if (m instanceof Follow f) {
            boolean hover = in(mx, my, x, y, w, ROW_H);
            ctx.fill(x, y, x + w, y + ROW_H, hover ? 0xDD2A2A2A : 0xDD151515);
            ctx.drawTextWithShadow(tr, "Targets (" + f.getTargets().size() + ") ...",
                x + 4, y + 3, 0xFFFFD866);
            if (hover) {
                hoverText = "Choose which entities Follow walks toward.";
                if (lClick) MinecraftClient.getInstance().setScreen(new EntityPickerScreen(f));
            }
            y += ROW_H;
        }
        return y;
    }

    static boolean in(int mx, int my, int x, int y, int w, int h) {
        return mx >= x && mx < x + w && my >= y && my < y + h;
    }
}
