package com.eio.client.event;

/** Fired once per client tick while in a world. */
public class TickEvent extends Event {}
