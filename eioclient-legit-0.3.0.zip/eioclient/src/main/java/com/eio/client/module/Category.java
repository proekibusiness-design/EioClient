package com.eio.client.module;

public enum Category { MOVEMENT, COMBAT, RENDER, PLAYER, WORLD, MISC }
