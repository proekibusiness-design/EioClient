package com.eio.client.module.modules;

import com.eio.client.module.Category;
import com.eio.client.module.Module;

/** Holds the forward key for you. */
public class AutoWalk extends Module {
    public AutoWalk() {
        super("AutoWalk", "Walks forward automatically.", Category.MOVEMENT);
    }

    @Override
    public void onTick() {
        mc.options.forwardKey.setPressed(true);
    }

    @Override
    protected void onDisable() {
        if (mc.options != null) mc.options.forwardKey.setPressed(false);
    }
}
