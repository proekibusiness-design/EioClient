package com.eio.client.module.modules;

import com.eio.client.EioClient;
import com.eio.client.TitleBranding;
import com.eio.client.module.Category;
import com.eio.client.module.Module;
import com.eio.client.setting.BoolSetting;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;

import java.util.Comparator;
import java.util.List;

/** On-screen overlay: watermark, coordinates, FPS and an enabled-module list. */
public class Hud extends Module {
    private final BoolSetting watermark = addSetting(new BoolSetting("Watermark", true));
    private final BoolSetting coords = addSetting(new BoolSetting("Coordinates", true));
    private final BoolSetting fps = addSetting(new BoolSetting("FPS", true));
    private final BoolSetting moduleList = addSetting(new BoolSetting("Module list", true));

    public Hud() {
        super("HUD", "Shows the watermark, coordinates, FPS and active modules.", Category.RENDER);
        setEnabled(true); // on by default; a saved config can override this
    }

    /** Called every frame from the HUD render callback while enabled. */
    public void render(DrawContext ctx) {
        if (mc.player == null || mc.options.hudHidden) return;
        TextRenderer tr = mc.textRenderer;
        int y = 4;

        if (watermark.get()) {
            TitleBranding.drawRainbow(ctx, tr, "Eio Client", 4, y);
            y += 11;
        }
        if (coords.get()) {
            String s = String.format("XYZ: %.1f %.1f %.1f", mc.player.getX(), mc.player.getY(), mc.player.getZ());
            ctx.drawTextWithShadow(tr, s, 4, y, 0xFFFFFFFF);
            y += 11;
        }
        if (fps.get()) {
            ctx.drawTextWithShadow(tr, "FPS: " + mc.getCurrentFps(), 4, y, 0xFFFFFFFF);
        }

        if (moduleList.get()) {
            List<Module> active = EioClient.modules.getAll().stream()
                .filter(m -> m.isEnabled() && m != this)
                .sorted(Comparator.comparingInt((Module m) -> -tr.getWidth(m.getName())))
                .toList();
            long t = System.currentTimeMillis();
            int right = ctx.getScaledWindowWidth() - 4;
            int ry = 4;
            for (int i = 0; i < active.size(); i++) {
                String name = active.get(i).getName();
                float hue = (((t % 3000L) / 3000f) + i * 0.07f) % 1f;
                ctx.drawTextWithShadow(tr, name, right - tr.getWidth(name), ry,
                    0xFF000000 | TitleBranding.hsvToRgb(hue));
                ry += 10;
            }
        }
    }
}
