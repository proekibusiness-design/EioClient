package com.eio.client.event;

/** Marker base class for everything posted on the EventBus. */
public abstract class Event {
    private boolean cancelled;

    public boolean isCancelled() { return cancelled; }
    public void cancel() { this.cancelled = true; }
}
