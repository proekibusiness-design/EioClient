package com.eio.client.gui;

import net.minecraft.client.MinecraftClient;
import org.lwjgl.glfw.GLFW;

/**
 * Polls raw key/mouse state from GLFW. Using polling instead of Screen
 * callbacks keeps the GUI code independent of Minecraft's input-API changes.
 * (If the window handle accessor is renamed in your version, fix it here.)
 */
public final class Input {
    private Input() {}

    private static long handle() {
        return MinecraftClient.getInstance().getWindow().getHandle();
    }

    public static boolean keyDown(int glfwKey) {
        return GLFW.glfwGetKey(handle(), glfwKey) == GLFW.GLFW_PRESS;
    }

    public static boolean mouseDown(int glfwButton) {
        return GLFW.glfwGetMouseButton(handle(), glfwButton) == GLFW.GLFW_PRESS;
    }
}
