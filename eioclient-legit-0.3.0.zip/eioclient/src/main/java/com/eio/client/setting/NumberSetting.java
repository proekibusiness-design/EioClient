package com.eio.client.setting;

public class NumberSetting extends Setting<Double> {
    private final double min, max, step;

    public NumberSetting(String name, double defaultValue, double min, double max, double step) {
        super(name, clamp(defaultValue, min, max));
        this.min = min; this.max = max; this.step = step;
    }

    @Override public void set(Double v) { super.set(clamp(v, min, max)); }

    public double getMin() { return min; }
    public double getMax() { return max; }
    public double getStep() { return step; }
    public int getInt() { return (int) Math.round(get()); }
    public float getFloat() { return get().floatValue(); }

    private static double clamp(double v, double lo, double hi) { return Math.max(lo, Math.min(hi, v)); }
}
