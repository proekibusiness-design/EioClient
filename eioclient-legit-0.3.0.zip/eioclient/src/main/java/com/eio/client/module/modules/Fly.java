package com.eio.client.module.modules;

import com.eio.client.module.Category;
import com.eio.client.module.Module;
import com.eio.client.setting.NumberSetting;

/** Creative-style flight with an adjustable speed. */
public class Fly extends Module {
    private final NumberSetting speed = addSetting(new NumberSetting("Speed", 0.10, 0.05, 1.0, 0.05));

    public Fly() {
        super("Fly", "Creative-style flight (double-tap jump to start flying).", Category.MOVEMENT);
    }

    @Override
    public void onTick() {
        if (mc.player == null) return;
        var abilities = mc.player.getAbilities();
        abilities.allowFlying = true;
        abilities.setFlySpeed(speed.getFloat());
    }

    @Override
    protected void onDisable() {
        if (mc.player == null) return;
        var abilities = mc.player.getAbilities();
        boolean legit = mc.player.isCreative() || mc.player.isSpectator();
        abilities.allowFlying = legit;
        if (!legit) abilities.flying = false;
        abilities.setFlySpeed(0.05f);
    }
}
