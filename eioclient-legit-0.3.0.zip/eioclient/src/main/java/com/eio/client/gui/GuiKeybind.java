package com.eio.client.gui;

import net.minecraft.client.MinecraftClient;
import org.lwjgl.glfw.GLFW;

/** Right Shift opens and closes the Eio Client GUI. Call tick() every client tick. */
public final class GuiKeybind {
    public static final int OPEN_KEY = GLFW.GLFW_KEY_RIGHT_SHIFT;
    private static boolean wasDown;

    private GuiKeybind() {}

    public static void tick(MinecraftClient client) {
        boolean down = Input.keyDown(OPEN_KEY);
        if (ClickGuiScreen.isListening()) { wasDown = down; return; }
        if (down && !wasDown) {
            if (client.currentScreen instanceof ClickGuiScreen
                    || client.currentScreen instanceof EntityPickerScreen) {
                client.setScreen(null);
            } else if (client.currentScreen == null && client.player != null) {
                client.setScreen(new ClickGuiScreen());
            }
        }
        wasDown = down;
    }
}
