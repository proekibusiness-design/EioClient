package com.eio.client.module;

import com.eio.client.event.EventBus;
import com.eio.client.event.TickEvent;
import com.eio.client.gui.ClickGuiScreen;
import com.eio.client.gui.Input;
import com.eio.client.module.modules.AutoWalk;
import com.eio.client.module.modules.Fly;
import com.eio.client.module.modules.Follow;
import com.eio.client.module.modules.Fullbright;
import com.eio.client.module.modules.Hud;
import com.eio.client.module.modules.Sprint;
import net.minecraft.client.MinecraftClient;
import net.minecraft.text.Text;
import com.eio.client.config.Config;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ModuleManager {
    private final List<Module> modules = new ArrayList<>();
    private final Map<Module, Boolean> keyState = new HashMap<>();

    public ModuleManager(EventBus bus) {
        // Register modules here.
        register(new Sprint());
        register(new Follow());
        register(new Fly());
        register(new AutoWalk());
        register(new Hud());
        register(new Fullbright());

        bus.subscribe(TickEvent.class, e -> {
            for (Module m : modules) {
                if (m.isEnabled()) m.onTick();
            }
        });
    }

    private void register(Module module) { modules.add(module); }

    public List<Module> getAll() { return List.copyOf(modules); }

    public Module get(String name) {
        for (Module m : modules) {
            if (m.getName().equalsIgnoreCase(name)) return m;
        }
        return null;
    }

    public <T extends Module> T get(Class<T> type) {
        for (Module m : modules) {
            if (type.isInstance(m)) return type.cast(m);
        }
        return null;
    }

    public List<Module> getByCategory(Category c) {
        return modules.stream().filter(m -> m.getCategory() == c).toList();
    }

    /** Polls module keybinds; call once per client tick. Binds only fire with no screen open. */
    public void handleKeys(MinecraftClient client) {
        boolean canAct = client.currentScreen == null && client.player != null
            && !ClickGuiScreen.isListening();
        for (Module m : modules) {
            if (m.getKey() < 0) continue;
            boolean down = Input.keyDown(m.getKey());
            boolean was = keyState.getOrDefault(m, false);
            keyState.put(m, down);
            if (down && !was && canAct) {
                m.toggle();
                Config.save(this);
                client.player.sendMessage(
                    Text.literal(m.getName() + (m.isEnabled() ? " ON" : " OFF")), true);
            }
        }
    }
}
