package com.eio.client.module.modules;

import com.eio.client.module.Category;
import com.eio.client.module.Module;
import com.eio.client.setting.BoolSetting;

/** Example module: keeps you sprinting while you hold forward. */
public class Sprint extends Module {
    private final BoolSetting hungerCheck = addSetting(new BoolSetting("Hunger check", true));

    public Sprint() {
        super("Sprint", "Automatically sprints while moving forward.", Category.MOVEMENT);
    }

    @Override
    public void onTick() {
        if (mc.player == null) return;
        boolean hungry = hungerCheck.get() && mc.player.getHungerManager().getFoodLevel() <= 6;
        if (mc.options.forwardKey.isPressed() && !mc.player.horizontalCollision && !hungry) {
            mc.player.setSprinting(true);
        }
    }

    @Override
    protected void onDisable() {
        if (mc.player != null) mc.player.setSprinting(false);
    }
}
