package com.eio.client.setting;

/** A text value. Edited in config/eioclient.json (the GUI shows it read-only). */
public class StringSetting extends Setting<String> {
    public StringSetting(String name, String defaultValue) { super(name, defaultValue); }
}
