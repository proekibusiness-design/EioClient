package com.eio.client.config;

import com.eio.client.module.Module;
import com.eio.client.module.ModuleManager;
import com.eio.client.setting.BoolSetting;
import com.eio.client.setting.ModeSetting;
import com.eio.client.setting.NumberSetting;
import com.eio.client.setting.Setting;
import com.eio.client.setting.StringSetting;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.Reader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;

/**
 * Saves/loads module state (enabled, keybind, settings, extras) to
 * <config dir>/eioclient.json.
 */
public final class Config {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    private Config() {}

    private static Path file() {
        return FabricLoader.getInstance().getConfigDir().resolve("eioclient.json");
    }

    public static void save(ModuleManager manager) {
        if (manager == null) return;
        JsonObject modules = new JsonObject();
        for (Module m : manager.getAll()) {
            JsonObject o = new JsonObject();
            o.addProperty("enabled", m.isEnabled());
            o.addProperty("key", m.getKey());

            JsonObject settings = new JsonObject();
            for (Setting<?> s : m.getSettings()) {
                if (s instanceof BoolSetting b) settings.addProperty(s.getName(), b.get());
                else if (s instanceof NumberSetting n) settings.addProperty(s.getName(), n.get());
                else if (s instanceof ModeSetting ms) settings.addProperty(s.getName(), ms.get());
                else if (s instanceof StringSetting ss) settings.addProperty(s.getName(), ss.get());
            }
            o.add("settings", settings);
            m.saveExtra(o);
            modules.add(m.getName(), o);
        }
        JsonObject root = new JsonObject();
        root.addProperty("version", 1);
        root.add("modules", modules);

        try {
            Path f = file();
            Files.createDirectories(f.getParent());
            Path tmp = f.resolveSibling("eioclient.json.tmp");
            Files.writeString(tmp, GSON.toJson(root), StandardCharsets.UTF_8);
            try {
                Files.move(tmp, f, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
            } catch (java.nio.file.AtomicMoveNotSupportedException ex) {
                Files.move(tmp, f, StandardCopyOption.REPLACE_EXISTING);
            }
        } catch (IOException e) {
            System.err.println("[Eio Client] Could not save config: " + e);
        }
    }

    public static void load(ModuleManager manager) {
        Path f = file();
        if (!Files.exists(f)) return;
        try (Reader r = Files.newBufferedReader(f, StandardCharsets.UTF_8)) {
            JsonObject root = JsonParser.parseReader(r).getAsJsonObject();
            JsonObject modules = root.getAsJsonObject("modules");
            if (modules == null) return;

            for (Module m : manager.getAll()) {
                if (!modules.has(m.getName())) continue;
                try {
                    JsonObject o = modules.getAsJsonObject(m.getName());
                    if (o.has("key")) m.setKey(o.get("key").getAsInt());

                    JsonObject st = o.has("settings") ? o.getAsJsonObject("settings") : new JsonObject();
                    for (Setting<?> s : m.getSettings()) {
                        if (!st.has(s.getName())) continue;
                        if (s instanceof BoolSetting b) b.set(st.get(s.getName()).getAsBoolean());
                        else if (s instanceof NumberSetting n) n.set(st.get(s.getName()).getAsDouble());
                        else if (s instanceof ModeSetting ms) {
                            String v = st.get(s.getName()).getAsString();
                            if (ms.getModes().contains(v)) ms.set(v);
                        } else if (s instanceof StringSetting ss) {
                            ss.set(st.get(s.getName()).getAsString());
                        }
                    }
                    m.loadExtra(o);
                    if (o.has("enabled")) m.setEnabled(o.get("enabled").getAsBoolean());
                } catch (RuntimeException ex) {
                    System.err.println("[Eio Client] Skipping bad config entry for " + m.getName() + ": " + ex);
                }
            }
        } catch (IOException | RuntimeException e) {
            System.err.println("[Eio Client] Could not load config: " + e);
            // Preserve a broken config for recovery instead of silently overwriting it later.
            try {
                Path broken = f.resolveSibling("eioclient.json.broken");
                Files.copy(f, broken, StandardCopyOption.REPLACE_EXISTING);
            } catch (IOException ignored) {}
        }
    }
}
