package com.eio.client.setting;

import java.util.List;

public class ModeSetting extends Setting<String> {
    private final List<String> modes;

    public ModeSetting(String name, String defaultMode, String... modes) {
        super(name, defaultMode);
        this.modes = List.of(modes);
    }

    public List<String> getModes() { return modes; }

    public void cycle() {
        int i = modes.indexOf(get());
        set(modes.get((i + 1) % modes.size()));
    }

    public boolean is(String mode) { return get().equalsIgnoreCase(mode); }
}
