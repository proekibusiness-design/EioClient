package com.eio.client.module.modules;

import com.eio.client.module.Category;
import com.eio.client.module.Module;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;

/** Client-side night vision that avoids deleting a pre-existing night-vision effect. */
public class Fullbright extends Module {
    private StatusEffectInstance injected;

    public Fullbright() {
        super("Fullbright", "See clearly in the dark.", Category.RENDER);
    }

    @Override
    public void onTick() {
        if (mc.player == null) return;
        StatusEffectInstance current = mc.player.getStatusEffect(StatusEffects.NIGHT_VISION);

        // Never overwrite a real/server-provided effect. Only maintain the instance we added.
        if (current != null && current != injected) {
            injected = null;
            return;
        }
        if (current == null || current.getDuration() < 300) {
            injected = new StatusEffectInstance(StatusEffects.NIGHT_VISION, 1000, 0, false, false, false);
            mc.player.addStatusEffect(injected);
        }
    }

    @Override
    protected void onDisable() {
        if (mc.player != null && injected != null
                && mc.player.getStatusEffect(StatusEffects.NIGHT_VISION) == injected) {
            mc.player.removeStatusEffect(StatusEffects.NIGHT_VISION);
        }
        injected = null;
    }
}
