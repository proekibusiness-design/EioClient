package com.eio.client.event;

import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.function.Consumer;

/**
 * Minimal type-keyed event bus.
 *
 *   bus.subscribe(TickEvent.class, e -> ...);
 *   bus.post(new TickEvent());
 *
 * Add new events (packets, render, key input...) by subclassing Event and
 * posting them from a Mixin or a Fabric API callback.
 */
public class EventBus {
    private final Map<Class<? extends Event>, List<Consumer<? extends Event>>> listeners =
        new ConcurrentHashMap<>();

    public <T extends Event> Consumer<T> subscribe(Class<T> type, Consumer<T> listener) {
        listeners.computeIfAbsent(type, k -> new CopyOnWriteArrayList<>()).add(listener);
        return listener;
    }

    public <T extends Event> void unsubscribe(Class<T> type, Consumer<T> listener) {
        List<Consumer<? extends Event>> list = listeners.get(type);
        if (list != null) list.remove(listener);
    }

    @SuppressWarnings("unchecked")
    public <T extends Event> T post(T event) {
        List<Consumer<? extends Event>> list = listeners.get(event.getClass());
        if (list != null) {
            for (Consumer<? extends Event> l : list) {
                ((Consumer<T>) l).accept(event);
            }
        }
        return event;
    }
}
