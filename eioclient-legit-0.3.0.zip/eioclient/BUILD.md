# Building Eio Client

You need: Java 21 and Gradle 8.12 or newer (gradle.org/install). Internet access is needed
on the first build (it downloads Minecraft and Fabric).

    gradle build            # produces build/libs/eioclient-0.2.0.jar
    gradle runClient        # or: launch Minecraft with the mod loaded, to test

(Optional: run `gradle wrapper` once, then use ./gradlew instead of gradle.)

Install: put build/libs/eioclient-0.2.0.jar (not the -sources jar) and the Fabric API jar for
the same Minecraft version into .minecraft/mods, with the Fabric Loader profile selected.

Other Minecraft version: edit gradle.properties with the numbers from
https://fabricmc.net/develop/template and adjust the "minecraft" line in
src/main/resources/fabric.mod.json. Newer versions may need small code changes; paste
any compile errors and I'll fix them.
